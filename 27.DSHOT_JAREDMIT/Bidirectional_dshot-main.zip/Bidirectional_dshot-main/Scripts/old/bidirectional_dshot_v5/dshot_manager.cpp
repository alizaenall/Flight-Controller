/**
 * @file dshot_manager.cpp
 * @brief DMA-enabled bidirectional dshot communication protocol manager class for multiple ESCs. Adapted from teensyshot.
 * @author Jared Boyer <jaredb@mit.edu>
 * @date 20 Jul 2021
 */

#include "dshot_manager.h"

#if defined(__IMXRT1062__) // teensy 4.0
#define F_TMR F_BUS_ACTUAL
#endif

uint32_t start;
uint32_t RPM;

const uint16_t DSHOT_short_pulse  = uint64_t(F_TMR) * DSHOT_SP_DURATION / 1000000000;     // DSHOT short pulse duration (nb of F_BUS periods)
const uint16_t DSHOT_long_pulse   = uint64_t(F_TMR) * DSHOT_LP_DURATION / 1000000000;     // DSHOT long pulse duration (nb of F_BUS periods)
const uint16_t DSHOT_bit_length   = uint64_t(F_TMR) * DSHOT_BT_DURATION / 1000000000;     // DSHOT bit duration (nb of F_BUS periods)

static constexpr uint16_t telemetry = 0; // No telemetry request for bidirectional dshot

IntervalTimer tx_timer;
IntervalTimer rx_timer;

// ------------------------------------------------------------ //
// eFlexPWM module & DMA interactions config
// ------------------------------------------------------------ //

// DMA eFlexPWM modules
volatile IMXRT_FLEXPWM_t*  DSHOT_mods[MAX_ESC]  = { &IMXRT_FLEXPWM2,
                                                    &IMXRT_FLEXPWM1,
                                                    &IMXRT_FLEXPWM4,
                                                    &IMXRT_FLEXPWM4,
                                                    &IMXRT_FLEXPWM4,
                                                    &IMXRT_FLEXPWM2
                                                  };

// DMA eFlexPWM submodules
volatile uint8_t          DSHOT_sm[MAX_ESC]     = { 0,
                                                    3,
                                                    2,
                                                    0,
                                                    1,
                                                    2
                                                  };

// DMA eFlexPWM submodule PWM channel selector: A=0, B=1, X=2
volatile uint8_t          DSHOT_abx[MAX_ESC]    = { 0,
                                                    0,
                                                    0,
                                                    0,
                                                    0,
                                                    1
                                                  };

// Output pins
volatile uint8_t          DSHOT_pin[MAX_ESC]    = { 4,
                                                    8,
                                                    2,
                                                    22,
                                                    23,
                                                    9
                                                  };

// Output pin ALT mux
volatile uint8_t          DSHOT_pinmux[MAX_ESC] = { 1,
                                                    6,
                                                    1,
                                                    1,
                                                    1,
                                                    2
                                                  };

// DMA source
volatile uint8_t          DSHOT_dmamux[MAX_ESC] = { DMAMUX_SOURCE_FLEXPWM2_WRITE0,
                                                    DMAMUX_SOURCE_FLEXPWM1_WRITE3,
                                                    DMAMUX_SOURCE_FLEXPWM4_WRITE2,
                                                    DMAMUX_SOURCE_FLEXPWM4_WRITE0,
                                                    DMAMUX_SOURCE_FLEXPWM4_WRITE1,
                                                    DMAMUX_SOURCE_FLEXPWM2_WRITE2
                                                  };

// DMA objects
DMAChannel          dma[MAX_ESC];

// DMA data
volatile uint16_t   DSHOT_dma_data[MAX_ESC][DSHOT_DMA_LENGTH];

// DSHOT data
volatile uint16_t   DSHOT_signals[MAX_ESC]; // Unassembled throttle commands from 0-2047

// ------------------------------------------------------------ //
// Dshot typedef for Rx management
// ------------------------------------------------------------ //

typedef struct {
  struct {
    void(*ISR)(void);
    volatile int timeRecord[RX_SIGNAL_LENGTH] = {0};
    volatile unsigned long lastTime;
    volatile int ISR_counter;
    unsigned long CHECKSUM_ERR_COUNTER = 0;
    unsigned long CHECKSUM_SUCCESS_COUNTER = 0;
  } line[MAX_ESC];
  bool decode_flag = false;
} DSHOT_t;

DSHOT_t dshot_comm;

/*
 * Pin change interrupt service routine for pulse length measurement
 */
#define pulselength_ISR( DSHOT_CHANNEL ) \
void pulselength_ISR_ ## DSHOT_CHANNEL( void ) { \
  if( dshot_comm.line[DSHOT_CHANNEL].ISR_counter == 0 ){ \
    dshot_comm.line[DSHOT_CHANNEL].lastTime = ARM_DWT_CYCCNT; \
    dshot_comm.line[DSHOT_CHANNEL].ISR_counter++; \
  } else { \
    dshot_comm.line[DSHOT_CHANNEL].timeRecord[ dshot_comm.line[DSHOT_CHANNEL].ISR_counter - 1 ] = ARM_DWT_CYCCNT - dshot_comm.line[DSHOT_CHANNEL].lastTime; \
    dshot_comm.line[DSHOT_CHANNEL].lastTime = ARM_DWT_CYCCNT; \
    dshot_comm.line[DSHOT_CHANNEL].ISR_counter++; \
  } \
}

pulselength_ISR( 0 );
pulselength_ISR( 1 );
pulselength_ISR( 2 );
pulselength_ISR( 3 );
pulselength_ISR( 4 );
pulselength_ISR( 5 );

void (*DSHOT_RX_ISR[6])( void ) = { pulselength_ISR_0,
                                    pulselength_ISR_1,
                                    pulselength_ISR_2,
                                    pulselength_ISR_3,
                                    pulselength_ISR_4,
                                    pulselength_ISR_5
                                  };

/*
 * DMA termination interrupt service routine (ISR) for each DMA channel
 */
#define DSHOT_DMA_interrupt_routine( DSHOT_CHANNEL ) \
void DSHOT_DMA_interrupt_routine_ ## DSHOT_CHANNEL( void ) { \
  dma[DSHOT_CHANNEL].clearInterrupt( ); \
  (*DSHOT_mods[DSHOT_CHANNEL]).MCTRL &= ~( FLEXPWM_MCTRL_RUN( 1 << DSHOT_sm[DSHOT_CHANNEL] ) );  \
  pinMode(DSHOT_pin[DSHOT_CHANNEL], INPUT); \
  attachInterrupt(DSHOT_pin[DSHOT_CHANNEL], DSHOT_RX_ISR[DSHOT_CHANNEL], CHANGE); \
}

DSHOT_DMA_interrupt_routine( 1 );
DSHOT_DMA_interrupt_routine( 2 );
DSHOT_DMA_interrupt_routine( 3 );
DSHOT_DMA_interrupt_routine( 4 );
DSHOT_DMA_interrupt_routine( 5 );

// The first ISR has to contain additional timer setup to attach an interrupt RX_WAIT time from now
void DSHOT_DMA_interrupt_routine_0( void ) {
  dma[0].clearInterrupt( );
  Serial.print(micros() - start); Serial.println("DMA done");
  (*DSHOT_mods[0]).MCTRL &= ~( FLEXPWM_MCTRL_RUN( 1 << DSHOT_sm[0] ) );
  pinMode(DSHOT_pin[0], INPUT);
  attachInterrupt(DSHOT_pin[0], DSHOT_RX_ISR[0], CHANGE);
  rx_timer.begin(rx_ISR, RX_WAIT);
}

void (*DSHOT_DMA_ISR[6])( void )  = { DSHOT_DMA_interrupt_routine_0,
                                      DSHOT_DMA_interrupt_routine_1,
                                      DSHOT_DMA_interrupt_routine_2,
                                      DSHOT_DMA_interrupt_routine_3,
                                      DSHOT_DMA_interrupt_routine_4,
                                      DSHOT_DMA_interrupt_routine_5
                                    };

// ------------------------------------------------------------ //
// DshotManager Class definitions
// ------------------------------------------------------------ //

DshotManager::DshotManager() {

  // Start ARM cycle counter
  ARM_DEMCR |= ARM_DEMCR_TRCENA; // debug exception monitor control register; enables trace and debug
  ARM_DWT_CTRL |= ARM_DWT_CTRL_CYCCNTENA;

}

void DshotManager::set_throttle_esc(int i, uint16_t input) {
  DSHOT_signals[i] = input;
  assemble_signal_esc(i);
}

void DshotManager::start_tx() {
  tx_timer.begin(tx_ISR, TX_WAIT);
}

// ------------------------------------------------------------ //
// Non-class methods
// ------------------------------------------------------------ //

void DMA_init(int i) {

  // Configure pins on the board as DSHOT outputs
  // These pins are configured as eFlexPWM (FLEXPWMn) PWM outputs
  *(portConfigRegister( DSHOT_pin[i] )) = DSHOT_pinmux[i];

  // Configure eFlexPWM modules and submodules for PWM generation
  // --- submodule specific registers ---
  // INIT: initial counter value
  // VAL0: PWM_X compare value
  // VAL1: counter max value
  // VAL2: must be 0 for edge-aligned PWM
  // VAL3: PWM_A compare value
  // VAL4: must be 0 for edge-aligned PWM
  // VAL5: PWM_B compare value
  // OCTRL: invert polarity of PWMq FLEXPWM_SMOCTRL_POLq
  // DMAEN: FLEXPWM_SMDMAEN_VALDE to enable DMA
  // --- module specific registers ---
  // OUTEN: output enable for submodule n and PWM q FLEXPWM_OUTEN_PWMq_EN( 1 << n )
  (*DSHOT_mods[i]).SM[DSHOT_sm[i]].INIT = 0;
  (*DSHOT_mods[i]).SM[DSHOT_sm[i]].VAL0 = 0;
  (*DSHOT_mods[i]).SM[DSHOT_sm[i]].VAL1 = DSHOT_bit_length;
  (*DSHOT_mods[i]).SM[DSHOT_sm[i]].VAL2 = 0;
  (*DSHOT_mods[i]).SM[DSHOT_sm[i]].VAL3 = 0;
  (*DSHOT_mods[i]).SM[DSHOT_sm[i]].VAL4 = 0;
  (*DSHOT_mods[i]).SM[DSHOT_sm[i]].VAL5 = 0;
  // Invert the polarity of signals for inverted dshot
  if ( DSHOT_abx[i] == 0 ) {
    (*DSHOT_mods[i]).SM[DSHOT_sm[i]].OCTRL = FLEXPWM_SMOCTRL_POLA;
    (*DSHOT_mods[i]).OUTEN |= FLEXPWM_OUTEN_PWMA_EN(1 << DSHOT_sm[i]);
  } else if ( DSHOT_abx[i] == 1 ) {
    (*DSHOT_mods[i]).SM[DSHOT_sm[i]].OCTRL = FLEXPWM_SMOCTRL_POLB;
    (*DSHOT_mods[i]).OUTEN |= FLEXPWM_OUTEN_PWMB_EN(1 << DSHOT_sm[i]);
  } else {
    /* Have yet to test if channel X PWM is a different polarity / behavior
    than channels A and B, so be wary of using channel X with this code */
    (*DSHOT_mods[i]).SM[DSHOT_sm[i]].OCTRL = FLEXPWM_SMOCTRL_POLX;
    (*DSHOT_mods[i]).OUTEN |= FLEXPWM_OUTEN_PWMX_EN(1 << DSHOT_sm[i]);
  }
  (*DSHOT_mods[i]).SM[DSHOT_sm[i]].DMAEN = FLEXPWM_SMDMAEN_VALDE;

  // Each DMA channel is linked to a unique eFlexPWM submodule
  // DMA channels are triggered by independent hardware events
  dma[i].sourceBuffer( DSHOT_dma_data[i], DSHOT_DMA_LENGTH * sizeof( uint16_t ));
  if ( DSHOT_abx[i] == 0 ) {
    dma[i].destination( (uint16_t&) (*DSHOT_mods[i]).SM[DSHOT_sm[i]].VAL3 );
  } else if ( DSHOT_abx[i] == 1 ) {
    dma[i].destination( (uint16_t&) (*DSHOT_mods[i]).SM[DSHOT_sm[i]].VAL5 );
  } else {
    dma[i].destination( (uint16_t&) (*DSHOT_mods[i]).SM[DSHOT_sm[i]].VAL0 );
  }
  dma[i].triggerAtHardwareEvent( DSHOT_dmamux[i] );
  dma[i].interruptAtCompletion( );
  dma[i].attachInterrupt( DSHOT_DMA_ISR[i] );
  dma[i].enable();

}

// ISR helper function
void assemble_signal_esc(int i) {

  int j;
  uint16_t input = DSHOT_signals[i];

  input = (input << 1) + telemetry;
  uint16_t crc = ( ~( input ^ (input >> 4) ^ (input >> 8) ) ) & 0x0F;
  uint16_t final_sig = (input << 4) + crc;

  // Convert to array of pulse lengths
  for ( j = 0; j < DSHOT_DSHOT_LENGTH; j++ ) {

    if ( final_sig & ( 1 << ( DSHOT_DSHOT_LENGTH - 1 - j ) ) ) {
      DSHOT_dma_data[i][j] = DSHOT_long_pulse;
    } else {
      DSHOT_dma_data[i][j] = DSHOT_short_pulse;
    }

  }

  // Append trailing 0's of DMA buffer
  for ( j = DSHOT_DSHOT_LENGTH; j < DSHOT_DMA_LENGTH; j++ ) {
    DSHOT_dma_data[i][j] = 0;
  }

}

uint16_t decode_signal(int i) {

  if (dshot_comm.line[i].timeRecord[0] == 0) { // Did we receive something?
    reset_array(i);
    return 0xffff;
  }

  int counter = 0;
  int num;
  uint32_t rx_sig = 0;

  for (int j = 0; j < RX_SIGNAL_LENGTH; j++) {
    num = rint( dshot_comm.line[i].timeRecord[j] / float(RX_BIT_TICK_LENGTH) );

    for (int k = 0; k < num; k++) {

      if (j % 2 == 1) { // If the array index is odd, which determines if it's a 1 or a 0
        rx_sig += (1 << (RX_SIGNAL_LENGTH - 1 - (counter + k)));
      }

    }

    counter += num;
  }

  // Pad 1's at the end
  for (int j = counter; j < RX_SIGNAL_LENGTH; j++) {
    rx_sig += (1 << (RX_SIGNAL_LENGTH - 1 - j));
  }

  uint32_t gcr = (rx_sig ^ (rx_sig >> 1));

  static const uint8_t gcr_map[32] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 10, 11, 0, 13, 14, 15,
    0, 0, 2, 3, 0, 5, 6, 7, 0, 0, 8, 1, 0, 4, 12, 0
  };

  uint16_t fin_sig = gcr_map[gcr & 0x1f];
  fin_sig |= gcr_map[(gcr >> 5) & 0x1f] << 4;
  fin_sig |= gcr_map[(gcr >> 10) & 0x1f] << 8;
  fin_sig |= gcr_map[(gcr >> 15) & 0x1f] << 12;

  uint16_t csum = fin_sig;
  csum = csum ^ (csum >> 8);
  csum = csum ^ (csum >> 4);

  // Checksum calculation
  if ((csum & 0xf) != 0xf) {
    Serial.println("Checksum err");
    dshot_comm.line[i].CHECKSUM_ERR_COUNTER++;
    reset_array(i);
    return 0xffff;
  }

  dshot_comm.line[i].CHECKSUM_SUCCESS_COUNTER++;

  // If we receive the max period, assume motor is not spinning
  if ((fin_sig >> 4) == 0x0fff) {
    reset_array(i);
    return 0;
  }

  uint8_t shift = fin_sig >> 13;
  uint16_t period_us = (((fin_sig >> 4) & 0b111111111) << shift);
  float eRPM = 1 / ((float)period_us / 60000000);
  reset_array(i);
  return eRPM / 7;

}

void reset_array(int i) {
  for (int j = 0; j < RX_SIGNAL_LENGTH; j++) {
    dshot_comm.line[i].timeRecord[j] = 0;
  }
}

// ------------------------------------------------------------ //
// ISR's
// ------------------------------------------------------------ //

// Turn on master control for each submodule being used
void tx_ISR( void ) {

  start = micros();
  Serial.print(micros() - start); Serial.println("Start tx");

  for ( int i = 0; i < MAX_ESC; i++ ) {
    DMA_init(i);
    assemble_signal_esc(i);
  }

  Serial.print(micros() - start); Serial.println("DMA & Assmebling");

  for ( int i = 0; i < MAX_ESC; i++ ) {
    (*DSHOT_mods[i]).MCTRL |= FLEXPWM_MCTRL_RUN( 1 << DSHOT_sm[i] );
  }

}

// Set flag to decode the signals in loop function
void rx_ISR( void ) {
  Serial.print(micros() - start); Serial.println("Rx ISR");
  int i;
  for (i = 0; i < MAX_ESC; i++) {
    detachInterrupt(DSHOT_pin[i]);
    dshot_comm.line[i].ISR_counter = 0;
  }
  for (i = 0; i < MAX_ESC; i++) {
    RPM = decode_signal(i);
  }
  Serial.print(micros() - start); Serial.println("Decoding finished");
}
