# Dshot
A library for a teensy 4.1 microcontroller to implemet ESC control with the Dshot protocol


The current iteration of this library can calculate the required string of binary to communicate with a Dshot ESC, but it has not yet been tested fully up to Dshot 1200
